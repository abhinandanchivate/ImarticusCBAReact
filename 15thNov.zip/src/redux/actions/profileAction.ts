import { NavigateFunction } from "react-router-dom";
import { Dispatch } from "redux";
import api from "../../components/utils/api";
import { ProfileType, ServerErrorType } from "../../global.types";
import {
  DeleteAccountType,
  GetProfileType,
  ProfileErrorType,
  SetAlertType,
  UpdateProfileFailedType,
  UpdateProfileType,
} from "../types";

export const getCurrentUserProfile =
  () => async (dispatch: Dispatch<GetProfileType | ProfileErrorType>) => {
    try {
      console.log("inside the profile action");
      const response = await api.get<ProfileType>("/profile/me");
      dispatch({
        type: "GET_PROFILE",
        payload: response.data,
      } as GetProfileType);
    } catch (error) {
      console.log(JSON.stringify(error));
      dispatch({
        type: "PROFILE_ERROR",
        payload: {
          status: "400",
          statusText: "Bad request",
        },
      } as ProfileErrorType);
    }
  };

export const createOrUpdateProfile =
  (data: ProfileType, navigate: NavigateFunction) =>
  async (
    dispatch: Dispatch<
      UpdateProfileType | UpdateProfileFailedType | SetAlertType
    >
  ) => {
    try {
      console.log(JSON.stringify(data));
      const result = await api.post<ProfileType>("/profile/", data);
      const { user, ...profileData } = result.data;
      console.log(JSON.stringify(profileData));
      console.log(JSON.stringify(api));
      dispatch({
        type: "UPDATE_PROFILE",
        payload: profileData,
      });
      navigate("/dashboard");
    } catch (error: any) {
      console.log(JSON.stringify(error));

      //alertError(error);
      dispatch({
        type: "UPDATE_PROFILE_FAILED",
      });
    }
  };

export const deleteAccount =
  () => async (dispatch: Dispatch<DeleteAccountType>) => {
    try {
      await api.delete("/api/user/delete");
      dispatch({ type: "DELETE_ACCOUT" });
    } catch (error) {
      //alertError(error);
    }
  };
