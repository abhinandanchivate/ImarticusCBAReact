import PropTypes from "prop-types";
import React, { ChangeEvent, FormEvent, Fragment, useState } from "react";
import { connect } from "react-redux";
import { redirect } from "react-router-dom";

import { Navigate } from "react-router-dom";
import { SignupParams } from "../../../global.types";
import { signup } from "../../../redux/actions/authAction";
import { AuthState } from "../../../redux/reducers/auth";
import { AppState } from "../../../redux/store";

function Register3({ signup, auth }: SignupProps) {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    password: "",
    password2: "",
    //errorObj: [],
  });

  const { email, password, password2, name } = formData;

  const onChange = (e: ChangeEvent<HTMLInputElement>) => {
    // do we need to update the state or not?
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    console.log("inside the form");
    if (password !== password2) {
      console.log("inside the if condition");
      // raise the alert
    } else {
      console.log("inside the else condition");
      signup({ name, password, email });
    }
  };

  if (auth.isAuthenticated) {
    //redirect("/dashboard");
    return <Navigate to={"/dashboard"}></Navigate>;
    // it should navigate us to dashboard page.
    // history
  }

  return (
    <Fragment>
      <h1 className="large text-primary">Sign Up</h1>
      <p className="lead">
        <i className="fas fa-user"></i> Create Your Account using FC
      </p>
      <form className="form" onSubmit={onSubmit}>
        <div className="form-group">
          <input
            type="text"
            placeholder="Name"
            name="name"
            required
            onChange={onChange}
            value={name}
          />
        </div>
        <div className="form-group">
          <input
            type="email"
            placeholder="Email Address"
            name="email"
            onChange={onChange}
            value={email}
          />

          <small className="form-text">
            This site uses Gravatar so if you want a profile image, use a
            Gravatar email
          </small>
        </div>
        <div className="form-group">
          <input
            type="password"
            placeholder="Password"
            name="password"
            onChange={onChange}
            value={password}
          />
        </div>
        <div className="form-group">
          <input
            type="password"
            placeholder="Confirm Password"
            name="password2"
            onChange={onChange}
            value={password2}
          />
        </div>

        <input type="submit" className="btn btn-primary" value="Register" />
      </form>
      <p className="my-1">
        Already have an account? <a href="login.html">Sign In</a>
      </p>
    </Fragment>
  );
}

Register3.propTypes = {};
//

const mapStateToProps = (state: AppState) => ({
  auth: state.auth,
});

const mapDispatchToProps = {
  signup,
  //setAlert
};

export default connect(mapStateToProps, mapDispatchToProps)(Register3);

interface SignupProps {
  // setAlert : typeof SetAlert
  signup: (signupParams: SignupParams) => void;
  auth: AuthState;
}

interface FormData {
  name: string;
  email: string;
  password: string;
  password2: string;
}
