export interface ServerErrorType {
  msg: string;
  value?: string;
  param?: string;
  location?: string;
}
