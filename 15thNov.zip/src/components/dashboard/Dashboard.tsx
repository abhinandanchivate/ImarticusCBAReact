import React, { useEffect } from "react";
import { connect } from "react-redux";

import { Link } from "react-router-dom";
import { AuthState } from "../../redux/reducers/auth";
import { ProfileState } from "../../redux/reducers/profiles";
import { AppState } from "../../redux/store";
import { getCurrentUserProfile } from "../../redux/actions/profileAction";
import DisplayExperience from "../profiles/DisplayExperience";

function DashBoard({
  getCurrentUserProfile,
  auth,
  profileState,
}: DashBoardProps) {
  useEffect(() => {
    return () => {
      getCurrentUserProfile();
    };
  }, [getCurrentUserProfile]);

  const { user } = auth;
  const { loading, profile } = profileState;

  if (loading) {
    return (
      <div className="loader-page">
        {/* <MoonLoader loading={true} size={100} color="#00A3B8" /> */}
      </div>
    );
  } else {
    return (
      <div>
        <h1 className="display-3 text-secondary font-weight-bold">Dashboard</h1>
        {profileState.profile ? (
          <div className="d-flex">
            <p className="lead mr-2 p-0 mb-0">Welcome {user && user.name} ✨</p>
            {/* <Link to={`/profile/${user!._id}`} className="btn btn-info mr-2">
              View Profile
            </Link> */}
            <DisplayExperience
              experience={profile.experience}
            ></DisplayExperience>
          </div>
        ) : (
          <div className="d-flex">
            <p className="lead mr-2 p-0 mb-0">no profile found 🤨</p>
            <Link to="/create-profile" className="btn btn-info">
              create now !
            </Link>
          </div>
        )}
        <div className="alert alert-warning text-center my-5">
          under construction notifications zone 😃
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state: AppState) => ({
  auth: state.auth,
  profile: state.profile,
});
const mapDispatchToProps = {
  getCurrentUserProfile,
  //setAlert
};
export default connect(mapStateToProps, mapDispatchToProps)(DashBoard);

interface DashBoardProps {
  getCurrentUserProfile: () => void;
  auth: AuthState;
  profileState: ProfileState;
}
