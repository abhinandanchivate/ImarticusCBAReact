import React from "react";

type Props = {};

const DisplayEduCredentials = (props: Props) => {
  return <div>DisplayEduCredentials</div>;
};

export default DisplayEduCredentials;
