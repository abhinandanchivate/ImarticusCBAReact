import axios from "axios";
import { request } from "http";

// create an instance of axios
const api = axios.create({
  baseURL: "/api",
  headers: { "Content-Type": "application/json" },
});

const token: string | null = localStorage.getItem("token");
if (token) {
  try {
    api.defaults.headers.common["x-auth-token"] = token;
  } catch (error) {
    console.log(JSON.stringify(error));
  }
} else {
  delete api.defaults.headers.common["x-auth-token"];
}

console.log(JSON.stringify(api));
export default api;
// creates an instance of the axios )
