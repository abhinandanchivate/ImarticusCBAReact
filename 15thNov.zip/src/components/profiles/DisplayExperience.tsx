import moment from "moment";
import React from "react";
import { ExperienceType } from "../../global.types";

type Props = { experience: ExperienceType[] | undefined };

const DisplayExperience = (prop: Props) => {
  const { experience } = prop;
  const display = experience?.map((exp, index) => (
    <div className="boxed" key={index}>
      <p>
        <strong>Job Title:</strong> {exp.jobTitle}
      </p>
      <p>
        <strong>Location:</strong> {exp.location}
      </p>
      <p>
        <strong>Company:</strong> {exp.company}
      </p>
      <p>
        <strong>Description:</strong> {exp.description}
      </p>
      <p>
        <strong>Started:</strong> {moment(exp.from).format("MMM DD YYYY")}
      </p>
      <p>
        <strong>Ended:</strong>{" "}
        {exp.current ? "no" : moment(exp.to).format("MMM DD YYYY")}
      </p>
    </div>
  ));
  return (
    <div>
      {experience?.length === 0 ? <div>There is no data</div> : display}
    </div>
  );
};

export default DisplayExperience;
