import React, { Component, Fragment } from "react";

type Props = {};

const Footer = (props: Props) => {
  return (
    <Fragment>
      <footer className="bg-dark text-white mt-5 p-4 text-center">
        Copyright &copy; {new Date().getFullYear()} Dev Connector
      </footer>
    </Fragment>
  );
};

export default Footer;
