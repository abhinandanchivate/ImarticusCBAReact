import React, { Component, Fragment } from "react";

type Props = {};

type State = {};

export default class Login extends Component<Props, State> {
  state = {};

  render() {
    return (
      <Fragment>
        <section className="container">
          <h1 className="large text-primary">Sign In</h1>
          <p className="lead">
            <i className="fas fa-user"></i> Sign into Your Account
          </p>
          <form className="form" action="dashboard.html">
            <div className="form-group">
              <input
                type="email"
                placeholder="Email Address"
                name="email"
                required
              />
            </div>
            <div className="form-group">
              <input type="password" placeholder="Password" name="password" />
            </div>
            <input type="submit" className="btn btn-primary" value="Login" />
          </form>
          <p className="my-1">
            Don't have an account? <a href="register.html">Sign Up</a>
          </p>
        </section>
      </Fragment>
    );
  }
}
