import React, { ChangeEvent, FormEvent, Fragment, useState } from "react";

import api from "../../utils/api";
import { IRegister } from "./IRegister";
import { ServerErrorType } from "./ServerErrorType";

type Props = {};

const Register2 = (props: Props) => {
  // use a hook called useState
  const [formData, setFormData] = useState<IRegister>({
    name: "",
    email: "",
    password: "",
    password2: "",
    //errorObj: [],
  });

  const { email, password, password2, name } = formData;
  // const name = formData.name

  const [errors, setErrors] = useState<ServerErrorType[]>([]);
  // formData : is used to refer the content for our hook
  // setFormData : it is a method to manipulate the state content : setState.
  // useState : it is a hook / method to initialize the state
  // {... field initializatins} : initialization of our state.

  const onChange = (e: ChangeEvent<HTMLInputElement>) => {
    // do we need to update the state or not?
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  const onSubmit = (e: FormEvent) => {
    const errorObjs: ServerErrorType[] = [];
    e.preventDefault();
    // axios call
    api
      .post("/users", formData)
      .then((res) => {
        console.log(JSON.stringify(res));
        // whatever the result / response we will print that response.
      })
      .catch((err) => {
        console.log(err.response.status);

        err.response.data.errors.forEach((e: any) => {
          if (e.param === "email") {
            errorObjs.push(e);
          }

          if (e.param === "password") {
            errorObjs.push(e);
          }
        });
        console.log(JSON.stringify(errorObjs));
        setErrors({ ...errorObjs });
        // this.setState({ ...this.state, errorObj: this.error });
        //this.setState({Object.keys(this.})
        //this.setState({ ...this.state, this.error});
      });
  };
  return (
    <Fragment>
      <h1 className="large text-primary">Sign Up</h1>
      <p className="lead">
        <i className="fas fa-user"></i> Create Your Account using FC
      </p>
      <form className="form" onSubmit={onSubmit}>
        <div className="form-group">
          <input
            type="text"
            placeholder="Name"
            name="name"
            required
            onChange={onChange}
            value={name}
          />
        </div>
        <div className="form-group">
          <input
            type="email"
            placeholder="Email Address"
            name="email"
            onChange={onChange}
            value={email}
          />

          <small className="form-text">
            This site uses Gravatar so if you want a profile image, use a
            Gravatar email
          </small>
        </div>
        <div className="form-group">
          <input
            type="password"
            placeholder="Password"
            name="password"
            onChange={onChange}
            value={password}
          />
        </div>
        <div className="form-group">
          <input
            type="password"
            placeholder="Confirm Password"
            name="password2"
            onChange={onChange}
            value={password2}
          />
        </div>

        <input type="submit" className="btn btn-primary" value="Register" />
      </form>
      <p className="my-1">
        Already have an account? <a href="login.html">Sign In</a>
      </p>
    </Fragment>
  );
};

export default Register2;
