import { ServerErrorType } from "./ServerErrorType";

export interface IRegister {
  name: string;
  email: string;
  password: string;
  password2: string;
}
