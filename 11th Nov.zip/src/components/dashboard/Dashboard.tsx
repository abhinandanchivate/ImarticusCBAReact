import PropTypes from "prop-types";
import React, { Fragment } from "react";
import { connect } from "react-redux";
import DashboardAction from "./DashboardAction";

const Dashboard = () => {
  return (
    <Fragment>
      <DashboardAction></DashboardAction>
    </Fragment>
  );
};

Dashboard.propTypes = {};

const mapStateToProps = () => ({});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
