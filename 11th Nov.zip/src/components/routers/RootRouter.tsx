import React, { Fragment } from "react";
import { Routes, Route } from "react-router-dom";
import Login from "../auth/login/Login";
import Register from "../auth/register/Register";
import Register2 from "../auth/register/Register2";
import Register3 from "../auth/register/Register3";
import Dashboard from "../dashboard/Dashboard";
import Landing from "../layout/Landing";

import Profiles from "../profiles/Profiles";
type Props = {};

const RootRouter = (props: Props) => {
  return (
    <Fragment>
      <Routes>
        <Route path="/" element={<Landing></Landing>}></Route>
        <Route path="/login" element={<Login></Login>}></Route>
        <Route path="/register" element={<Register3></Register3>}></Route>
        <Route path="/dashboard" element={<Dashboard></Dashboard>}></Route>
        <Route path="/profiles" element={<Profiles></Profiles>}></Route>
      </Routes>
    </Fragment>
  );
};

export default RootRouter;
