import React, { Component } from "react";

type Props = {};

type State = {};

export default class Profiles extends Component<Props, State> {
  state = {};

  render() {
    return <div>Profiles</div>;
  }
}
//tsrcc
