import React from "react";
import { BrowserRouter as Router, Route, NavLink } from "react-router-dom";

import logo from "./logo.svg";
import "./App.css";
import Landing from "./components/layout/Landing";
import Header from "./components/layout/Header";
import Footer from "./components/layout/Footer";
import RootRouter from "./components/routers/RootRouter";
import { Provider } from "react-redux";
import store from "./redux/store";
/// provider is the integration of react and redux

function App() {
  return (
    <div className="App">
      <Provider store={store}>
        <Router>
          <Header></Header>

          <RootRouter></RootRouter>

          <Footer></Footer>
        </Router>
      </Provider>
    </div>
  );
}

export default App;
