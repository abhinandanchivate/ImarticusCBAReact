import React from "react";
import { BrowserRouter as Router, Route, NavLink } from "react-router-dom";

import logo from "./logo.svg";
import "./App.css";
import Landing from "./components/layout/Landing";
import Header from "./components/layout/Header";
import Footer from "./components/layout/Footer";
import RootRouter from "./components/routers/RootRouter";

function App() {
  return (
    <div className="App">
      <Router>
        <Header></Header>

        <RootRouter></RootRouter>

        <Footer></Footer>
      </Router>
    </div>
  );
}

export default App;
