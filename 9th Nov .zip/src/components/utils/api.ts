import axios from "axios";

// create an instance of axios
const api = axios.create({
  baseURL: "/",
  headers: { "content-type": "application/json" },
});
export default api;
// creates an instance of the axios )
