import React, { Fragment } from "react";
import { Routes, Route } from "react-router-dom";
import Login from "../auth/login/Login";
import Register from "../auth/register/Register";
import Landing from "../layout/Landing";
import Profiles from "../profiles/Profiles";
type Props = {};

const RootRouter = (props: Props) => {
  return (
    <Fragment>
      <Routes>
        <Route path="/" element={<Landing></Landing>}></Route>
        <Route path="/login" element={<Login></Login>}></Route>
        <Route path="/register" element={<Register></Register>}></Route>
        <Route path="/profiles" element={<Profiles></Profiles>}></Route>
      </Routes>
    </Fragment>
  );
};

export default RootRouter;
