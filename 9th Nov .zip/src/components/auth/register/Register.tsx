import axios from "axios";
import React, { ChangeEvent, Component, Fragment } from "react";
import { IRegister } from "./IRegister";

type Props = {};

export default class Register extends Component<Props, IRegister> {
  // Props : attributes of the component. // we will use to get the input for our component.
  // props : smart and dumb components (dumb components.)

  // State : the state of the component we can hold the reqd data for our component.
  // state : is the predeined object.
  // the state will be initialized in the constructor.
  constructor(props: Props) {
    super(props); // it will help us to call the base class constructor.
    //
    this.state = { name: "", email: "", password: "", password2: "" };
  }

  onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // 1 . when the value of controller is changed then immediately update the state
    // 2. state is immutable
    // 3. usage of setState method : this method is from the base class and
    // responsible for updating the state of the component.

    console.log(e.target.name);
    console.log(e.target.value);
    this.setState({ ...this.state, [e.target.name]: e.target.value }); // this method is
    /// ...this.state : ...this.state : will provide all the attributes along with the value
    //used to update the state of the component.
  };
  onSubmit = (e: React.ChangeEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log(JSON.stringify(this.state));
    axios.post();
    // url : to connect with the server for specific task
    // data : json object
    // content-type spec. application/json
  };

  render() {
    return (
      <Fragment>
        <h1 className="large text-primary">Sign Up</h1>
        <p className="lead">
          <i className="fas fa-user"></i> Create Your Account
        </p>
        <form className="form" onSubmit={this.onSubmit}>
          <div className="form-group">
            <input
              type="text"
              placeholder="Name"
              name="name"
              required
              onChange={this.onChange}
            />
          </div>
          <div className="form-group">
            <input
              type="email"
              placeholder="Email Address"
              name="email"
              onChange={this.onChange}
            />
            <small className="form-text">
              This site uses Gravatar so if you want a profile image, use a
              Gravatar email
            </small>
          </div>
          <div className="form-group">
            <input
              type="password"
              placeholder="Password"
              name="password"
              onChange={this.onChange}
            />
          </div>
          <div className="form-group">
            <input
              type="password"
              placeholder="Confirm Password"
              name="password2"
              onChange={this.onChange}
            />
          </div>

          <input type="submit" className="btn btn-primary" value="Register" />
        </form>
        <p className="my-1">
          Already have an account? <a href="login.html">Sign In</a>
        </p>
      </Fragment>
    );
  }
}
