import React, { Component, Fragment } from "react";

type Props = {};

type State = {};

export default class Footer extends Component<Props, State> {
  state = {};

  render() {
    // the presentable content will be returned by render method.
    return (
      <Fragment>
        <footer className="bg-dark text-white mt-5 p-4 text-center">
          Copyright &copy; {new Date().getFullYear()} Dev Connector
        </footer>
      </Fragment>
    );
  }
}
